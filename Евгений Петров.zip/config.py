DB_USER = "postgres"
DB_PASS = "postgres"
DB_HOST = "localhost"
DB_NAME = "simbirgo"
DB_PORT = 5432

JWT_ALGORITHM = "HS256"
JWT_SECRET_KEY = "JWT_SECRET_KEY"
