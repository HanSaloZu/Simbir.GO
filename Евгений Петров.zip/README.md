# Simbir.GO

1. pip install -r requirements.txt
2. python main.py

## URL: http://127.0.0.1:8000/ui-swagger